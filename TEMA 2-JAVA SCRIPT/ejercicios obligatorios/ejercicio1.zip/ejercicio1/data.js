/*5. Escriu un script de JavaScript que visualitzi el dia del mes, el número corresponent al mes, l'any, l'hora, el minut i els segons 
actuals. L'arxiu extern de JavaScript s'anomenarà: "data.js". */


/*var dia = new Date();
alert('Hoy es ' + dia.getDate() + '/' + (dia.getMonth()+1) + '/' + dia.getFullYear() + ' y la hora es ' + dia.getHours() + ':' + dia.getMinutes() + ':' + dia.getSeconds())*/
 document.write(new Date());
